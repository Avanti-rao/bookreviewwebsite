export FLASK_APP=wsgi.py
export FLASK_DEBUG=1
flask run

# gunicorn wsgi:app
